# Ruang Temu — Next.js Starter

Ini adalah fondasi awal aplikasi sungguhan untuk **Ruang Temu**: social productivity app untuk mahasiswa/remaja dengan liquid glass UI, ruang fokus, circle, tempat produktif, dan room online berbasis Zoom.

## Isi project

- `app/page.tsx` — halaman utama aplikasi.
- `components/RuangTemuApp.tsx` — UI liquid glass dan interaksi utama.
- `app/api/zoom/create-room/route.ts` — backend route untuk membuat Zoom meeting.
- `database/schema.sql` — schema Supabase/Postgres + RLS policies.
- `lib/supabase/*` — helper Supabase client/server.
- `.env.example` — contoh environment variables.

## Jalankan lokal

```bash
npm install
npm run dev
```

Buka:

```bash
http://localhost:3000
```

## Deploy ke Vercel

1. Upload folder ini ke GitHub.
2. Buka Vercel.
3. Import repository.
4. Tambahkan environment variables dari `.env.example`.
5. Deploy.

## Aktifkan Supabase

1. Buat project di Supabase.
2. Buka SQL Editor.
3. Paste isi `database/schema.sql`.
4. Jalankan SQL.
5. Buka Project Settings > API.
6. Salin:
   - Project URL → `NEXT_PUBLIC_SUPABASE_URL`
   - anon public key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - service role key → `SUPABASE_SERVICE_ROLE_KEY`
7. Masukkan key ke Vercel Environment Variables.

Catatan: `SUPABASE_SERVICE_ROLE_KEY` hanya boleh dipakai di server/backend, tidak boleh dipakai di komponen client.

## Aktifkan Zoom Meeting Creation

1. Masuk ke Zoom App Marketplace / Zoom Developer.
2. Buat app tipe **Server-to-Server OAuth**.
3. Salin credential:
   - Account ID → `ZOOM_ACCOUNT_ID`
   - Client ID → `ZOOM_CLIENT_ID`
   - Client Secret → `ZOOM_CLIENT_SECRET`
4. Tambahkan scope meeting yang dibutuhkan, minimal scope untuk membuat meeting.
5. Masukkan environment variables tersebut ke Vercel.
6. Redeploy project.
7. Buka tab **Room** di aplikasi, lalu klik **Buat room online**.

Jika environment Zoom belum dipasang, aplikasi otomatis masuk **demo mode**, sehingga UI tetap bisa diuji tanpa error.

## Batasan starter ini

- Belum ada login UI final.
- Belum ada dashboard admin.
- Belum ada chat realtime.
- Belum ada AI moderator asli.
- Zoom saat ini dipakai untuk membuat link meeting, belum embed Meeting SDK di dalam halaman.

## Roadmap setelah ini

1. Tambahkan login Google/email dengan Supabase Auth.
2. Hubungkan circle, room, event, dan focus session ke database.
3. Tambahkan realtime chat.
4. Tambahkan AI moderator.
5. Tambahkan admin moderation panel.
6. Tambahkan Zoom Meeting SDK bila ingin meeting tertanam langsung di aplikasi.
