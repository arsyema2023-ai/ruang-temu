import { NextResponse } from 'next/server';

type ZoomTokenResponse = {
  access_token: string;
  token_type: string;
  expires_in: number;
};

type ZoomMeetingResponse = {
  id: number;
  topic: string;
  join_url: string;
  start_url: string;
  password?: string;
};

function hasZoomEnv() {
  return Boolean(process.env.ZOOM_ACCOUNT_ID && process.env.ZOOM_CLIENT_ID && process.env.ZOOM_CLIENT_SECRET);
}

async function getZoomAccessToken(): Promise<string> {
  const accountId = process.env.ZOOM_ACCOUNT_ID;
  const clientId = process.env.ZOOM_CLIENT_ID;
  const clientSecret = process.env.ZOOM_CLIENT_SECRET;

  if (!accountId || !clientId || !clientSecret) {
    throw new Error('Zoom environment variables are not configured.');
  }

  const basic = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  const tokenUrl = `https://zoom.us/oauth/token?grant_type=account_credentials&account_id=${encodeURIComponent(accountId)}`;

  const response = await fetch(tokenUrl, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basic}`
    },
    cache: 'no-store'
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Zoom token request failed: ${response.status} ${text}`);
  }

  const data = (await response.json()) as ZoomTokenResponse;
  return data.access_token;
}

async function createZoomMeeting(topic: string, duration: number) {
  const token = await getZoomAccessToken();
  const response = await fetch('https://api.zoom.us/v2/users/me/meetings', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      topic,
      type: 1,
      duration,
      timezone: 'Asia/Jakarta',
      agenda: 'Ruang Temu online study room',
      settings: {
        waiting_room: true,
        join_before_host: false,
        participant_video: true,
        host_video: true,
        mute_upon_entry: true,
        approval_type: 0
      }
    }),
    cache: 'no-store'
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Zoom create meeting failed: ${response.status} ${text}`);
  }

  return (await response.json()) as ZoomMeetingResponse;
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const topic = typeof body.topic === 'string' && body.topic.trim() ? body.topic.trim().slice(0, 120) : 'Ruang Temu Online Room';
    const duration = Number.isFinite(Number(body.duration)) ? Math.min(Math.max(Number(body.duration), 15), 240) : 60;

    if (!hasZoomEnv()) {
      return NextResponse.json({
        ok: true,
        mode: 'demo',
        topic,
        join_url: 'https://zoom.us/',
        meeting_id: 'DEMO-ROOM',
        passcode: 'demo',
        message: 'Demo mode aktif karena kredensial Zoom belum dipasang di environment variables.'
      });
    }

    const meeting = await createZoomMeeting(topic, duration);

    return NextResponse.json({
      ok: true,
      mode: 'zoom',
      topic: meeting.topic,
      join_url: meeting.join_url,
      start_url: meeting.start_url,
      meeting_id: String(meeting.id),
      passcode: meeting.password ?? '',
      message: 'Zoom meeting berhasil dibuat dari backend Ruang Temu.'
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        mode: 'demo',
        topic: 'Ruang Temu Online Room',
        join_url: '#',
        message: error instanceof Error ? error.message : 'Terjadi kesalahan saat membuat room.'
      },
      { status: 500 }
    );
  }
}
