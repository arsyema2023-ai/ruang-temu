-- Ruang Temu database schema for Supabase/PostgreSQL
-- Jalankan file ini di Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Pengguna Ruang Temu',
  campus text,
  role text check (role in ('mahasiswa', 'siswa', 'mentor', 'admin')) default 'mahasiswa',
  interests text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.circles (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  topic text not null default 'umum',
  visibility text check (visibility in ('public', 'private', 'campus')) default 'public',
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.circle_members (
  circle_id uuid references public.circles(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  member_role text check (member_role in ('owner', 'moderator', 'member')) default 'member',
  joined_at timestamptz not null default now(),
  primary key (circle_id, user_id)
);

create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  circle_id uuid references public.circles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  title text not null,
  room_type text check (room_type in ('focus', 'discussion', 'class', 'hangout')) default 'focus',
  provider text check (provider in ('zoom', 'demo', 'other')) default 'demo',
  meeting_id text,
  join_url text,
  passcode text,
  starts_at timestamptz default now(),
  ends_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.focus_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  target text not null,
  duration_minutes int not null default 25 check (duration_minutes between 5 and 240),
  status text check (status in ('planned', 'running', 'done', 'cancelled')) default 'planned',
  reflection text,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

create table if not exists public.places (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  city text,
  category text check (category in ('library', 'cafe', 'campus', 'coworking', 'other')) default 'other',
  description text,
  wifi boolean default false,
  power_outlet boolean default false,
  noise_level text check (noise_level in ('quiet', 'moderate', 'loud')) default 'moderate',
  student_budget boolean default true,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  event_type text check (event_type in ('study_sprint', 'mini_class', 'discussion', 'offline_meetup')) default 'study_sprint',
  circle_id uuid references public.circles(id) on delete set null,
  place_id uuid references public.places(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  starts_at timestamptz not null,
  max_participants int default 8 check (max_participants between 2 and 200),
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  circle_id uuid references public.circles(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete set null,
  body text not null check (char_length(body) <= 4000),
  is_ai boolean default false,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.circles enable row level security;
alter table public.circle_members enable row level security;
alter table public.rooms enable row level security;
alter table public.focus_sessions enable row level security;
alter table public.places enable row level security;
alter table public.events enable row level security;
alter table public.messages enable row level security;

-- profiles
create policy "profiles are readable" on public.profiles for select using (true);
create policy "users can insert own profile" on public.profiles for insert with check (auth.uid() = id);
create policy "users can update own profile" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

-- circles
create policy "public circles are readable" on public.circles for select using (visibility = 'public' or created_by = auth.uid());
create policy "authenticated users can create circles" on public.circles for insert with check (auth.role() = 'authenticated' and created_by = auth.uid());
create policy "circle owners can update" on public.circles for update using (created_by = auth.uid()) with check (created_by = auth.uid());

-- circle members
create policy "memberships readable" on public.circle_members for select using (true);
create policy "users can join as themselves" on public.circle_members for insert with check (auth.uid() = user_id);
create policy "users can leave as themselves" on public.circle_members for delete using (auth.uid() = user_id);

-- rooms
create policy "rooms readable" on public.rooms for select using (true);
create policy "authenticated users can create rooms" on public.rooms for insert with check (auth.role() = 'authenticated' and created_by = auth.uid());
create policy "room creator can update" on public.rooms for update using (created_by = auth.uid()) with check (created_by = auth.uid());

-- focus sessions
create policy "users read own focus sessions" on public.focus_sessions for select using (auth.uid() = user_id);
create policy "users create own focus sessions" on public.focus_sessions for insert with check (auth.uid() = user_id);
create policy "users update own focus sessions" on public.focus_sessions for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- places and events
create policy "places readable" on public.places for select using (true);
create policy "authenticated users create places" on public.places for insert with check (auth.role() = 'authenticated' and created_by = auth.uid());
create policy "events readable" on public.events for select using (true);
create policy "authenticated users create events" on public.events for insert with check (auth.role() = 'authenticated' and created_by = auth.uid());

-- messages
create policy "messages readable" on public.messages for select using (true);
create policy "authenticated users send own messages" on public.messages for insert with check (auth.role() = 'authenticated' and (auth.uid() = user_id or is_ai = true));

-- Auto-create profile after signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
