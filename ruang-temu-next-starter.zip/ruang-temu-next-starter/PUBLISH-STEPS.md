# Langkah Publikasi Ruang Temu sebagai Aplikasi Online

## A. Upload ke GitHub

1. Buat repository baru: `ruang-temu`.
2. Upload semua isi folder ini.
3. Pastikan file `.env` tidak ikut di-upload.

## B. Deploy ke Vercel

1. Buka Vercel.
2. Klik Add New Project.
3. Pilih repository `ruang-temu`.
4. Framework akan terdeteksi sebagai Next.js.
5. Tambahkan environment variables.
6. Klik Deploy.

## C. Supabase

1. Buat project Supabase.
2. Jalankan `database/schema.sql` di SQL Editor.
3. Copy Project URL dan anon key ke Vercel.
4. Redeploy.

## D. Zoom

1. Buat app Server-to-Server OAuth di Zoom Developer.
2. Ambil Account ID, Client ID, Client Secret.
3. Tambahkan env di Vercel.
4. Redeploy.
5. Tes tombol Buat Room Online.

## E. Domain

Setelah aplikasi stabil:

1. Beli domain, contoh `ruangtemu.id`.
2. Tambahkan domain di Vercel > Project Settings > Domains.
3. Ikuti instruksi DNS dari Vercel.
